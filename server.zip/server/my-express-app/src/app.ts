import { validate, parse, type InitDataParsed } from '@telegram-apps/init-data-node';
import express, {
    type ErrorRequestHandler,
    type RequestHandler,
    type Response,
} from 'express';
import cors from 'cors';
import https from 'https';
import fs from 'fs';
import { getUserData } from './db';
import { updateDataById } from './db2';
import { updateUserFriends } from './db3';

// Флаги для отслеживания текущих операций
let isSavingData = false;
let isProcessingData = false;

/*
 * Sets init data in the specified Response object.
 * @param res - Response object.
 * @param initData - init data.
 */
function setInitData(res: Response, initData: InitDataParsed): void {
    res.locals.initData = initData;
}

/*
 * Extracts init data from the Response object.
 * @param res - Response object.
 * @returns Init data stored in the Response object. Can return undefined in case,
 * the client is not authorized.
 */
function getInitData(res: Response): InitDataParsed | undefined {
    return res.locals.initData;
}

/*
 * Middleware which authorizes the external client.
 * @param req - Request object.
 * @param res - Response object.
 * @param next - function to call the next middleware.
 */
const authMiddleware: RequestHandler = (req, res, next) => {
    const [authType, authData = ''] = (req.header('authorization') || '').split(' ');

    switch (authType) {
        case 'tma':
            try {
                validate(authData, token, {
                    expiresIn: 3600
                });
                setInitData(res, parse(authData));
                return next();
            } catch (e) {
                return next(e);
            }
        default:
            return next(new Error('Unauthorized'));
    }
};

/*
 * Middleware which shows the user init data.
 * @param _req
 * @param res - Response object.
 * @param next - function to call the next middleware.
 */
const showInitDataMiddleware: RequestHandler = (_req, res, next) => {
    const initData = getInitData(res);
    getUserData(String(initData?.user?.id))
        .then(userData => {
            if (!userData) {
                return res.status(404).json({ error: 'Пользователь не найден.' });
            }
            res.json(userData); // Отправка JSON-ответа
        })
        .catch(error => {
            console.error(error);
            res.status(500).json({ error: 'Произошла ошибка' });
        });
};

/**
 * Default error handling middleware.
 * @param err - handled error.
 * @param _req
 * @param res - Response object.
 */
const defaultErrorMiddleware: ErrorRequestHandler = (err, _req, res) => {
    res.status(500).json({
        error: err.message,
    });
};

// Handler to return response with status 200 for /save-data.
const saveDataHandler: RequestHandler = async (req, res) => {
    if (isSavingData || isProcessingData) {
        return res.status(503).json({ error: 'Работа в процессе. Пожалуйста, подождите.' });
    }

    isSavingData = true; // Устанавливаем флаг, что идет сохранение данных

    try {
        await updateDataById(String(req.body.id), req.body);
        res.status(200).json({ message: 'Данные успешно сохранены.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Ошибка при сохранении данных.' });
    } finally {
      isSavingData = false; // Сбрасываем флаг после завершения
    }
};

// Handler for /data route
const dataHandler: RequestHandler = async (req, res) => {
    if (isSavingData || isProcessingData) {
        return res.status(503).json({ error: 'Работа в процессе. Пожалуйста, подождите.' });
    }

    isProcessingData = true; // Устанавливаем флаг, что идет обработка данных

    try {
        await updateDataById(String(req.body.id), req.body); // Пример вызова функции
        res.status(200).json({ message: 'Данные успешно обработаны.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Ошибка при обработке данных.' });
    } finally {
        isProcessingData = false; // Сбрасываем флаг после завершения
    }
}
const friend: RequestHandler = async (req, res) => {
    console.log(req.body);
    updateUserFriends(req.body.username,req.body.name);
}
// Your secret bot token.
const token = '2099327124:AAFaMo9wQuWB7iQRGBfkH03iA_yufEsPSQw';

// Read SSL certificate and key files.
const sslOptions = {
    key: fs.readFileSync('/etc/ssl/1t1y2.key'),  // Путь к вашему приватному ключу
    cert: fs.readFileSync('/etc/ssl/1t1y2.crt') // Путь к вашему полному сертификату
};

// Create an Express applet and start listening to port 3000.
const app = express();
app.use(cors());
//app.use(express.urlencoded({ extended: true }));
app.use('/api', authMiddleware);
app.post('/api', showInitDataMiddleware);
app.post('/save-data', saveDataHandler); // Обработка POST-запросов для сохранения данных
app.post('/data', dataHandler); // Обработка POST-запросов для данных
app.post('/f',friend);
//app.use(defaultErrorMiddleware);

// Create an HTTPS server using the Express app and the SSL options.
https.createServer(sslOptions, app).listen(3000, () => {
    console.log('HTTPS Server is running on port 3000');
});
import { Pool } from 'pg';

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: '12345678',
  port: 5432,
});

// Тип для данных пользователя
interface UserData {
  id: number;
  username: string;
  friends: number;
  full_charge_available: number; // Изменили на тип INT
  full_charge_available_since: Date; // Новое свойство для хранения времени
  balance: bigint;
  claimed: object;
  hard_work_available: boolean;
  hard_work_available_since: Date; // Новое свойство для хранения времени
  energy_upgrade_cost: bigint;
  multitap_upgrade_cost: bigint;
  tap_limit: number;
  energi: number;
  time: Date;
  tapValue: number;
}

// Функция для получения или создания данных пользователя
export const getUserData = (name: string): Promise<UserData> => {
  // Получаем данные пользователя по имени
  return pool.query('SELECT * FROM user_data WHERE username = $1', [name])
    .then(res => {
      if (res.rows.length > 0) {
        // Если данные найдены, проверяем нужно ли обновление
        const userData: UserData = res.rows[0];
        const currentTime = new Date();
        if(userData.energi+(currentTime.getTime() - new Date(userData.time).getTime())/3000<userData.tap_limit){
          userData.energi=Math.floor(userData.energi+(currentTime.getTime() - new Date(userData.time).getTime())/3000);
        }
        else{
          userData.energi=userData.tap_limit;
        }
        // Проверяем, прошло ли 24 часа с момента последнего обновления full_charge_available
        if (userData.full_charge_available < 3 && 
            (currentTime.getTime() - new Date(userData.full_charge_available_since).getTime()) >= 24 * 60 * 60 * 1000) {
          userData.full_charge_available = 3;  // Восстанавливаем до 3
          userData.full_charge_available_since = currentTime;  // Записываем текущее время

          // Обновляем данные в базе данных
          pool.query(
            'UPDATE user_data SET full_charge_available = $1, full_charge_available_since = $2 WHERE id = $3',
            [userData.full_charge_available, userData.full_charge_available_since, userData.id]
          );
        }

        // Проверяем, прошло ли 24 часа с момента последнего обновления hard_work_available
        if (!userData.hard_work_available && 
            (currentTime.getTime() - new Date(userData.hard_work_available_since).getTime()) >= 24 * 60 * 60 * 1000) {
          userData.hard_work_available = true;  // Устанавливаем true
          userData.hard_work_available_since = currentTime;  // Записываем текущее время

          // Обновляем данные в базе данных
          pool.query(
            'UPDATE user_data SET hard_work_available = $1, hard_work_available_since = $2 WHERE id = $3',
            [userData.hard_work_available, userData.hard_work_available_since, userData.id]
          );
        }
        
        //console.log((currentTime.getTime() - new Date(userData.time).getTime())/3000,userData.energi);
        return userData;  // Возвращаем объект с обновлёнными данными
      } else {
        // Если данных нет, создаем нового пользователя
        const newUser: UserData = {
          id: 0, // Это временное значение
          username: name,
          friends: 0,
          full_charge_available: 3, // Начальное значение
          full_charge_available_since: new Date(), // Текущее время
          balance: BigInt(0),
          claimed: {'0': true, '25': true, '50': true},
          hard_work_available: true, // Начальное значение
          hard_work_available_since: new Date(), // Текущее время
          energy_upgrade_cost: BigInt(5000),
          multitap_upgrade_cost: BigInt(5000),
          tap_limit: 500,
          energi:500,
          time: new Date(),
          tapValue: 1,
        };
        return pool.query(
            `INSERT INTO user_data (username, friends, full_charge_available, full_charge_available_since, balance, claimed, hard_work_available, hard_work_available_since, energy_upgrade_cost, multitap_upgrade_cost, tap_limit, energi, time, tapValue) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING id`,
            [
              newUser.username,
              newUser.friends,
              newUser.full_charge_available,
              newUser.full_charge_available_since,
              newUser.balance,
              JSON.stringify(newUser.claimed),
              newUser.hard_work_available,
              newUser.hard_work_available_since,
              newUser.energy_upgrade_cost,
              newUser.multitap_upgrade_cost,
              newUser.tap_limit,
              newUser.energi,
              newUser.time,
              newUser.tapValue,
            ]
          ).then(insertRes => {
            // Возвращаем объект с новыми данными пользователя, включая ID
            return { ...newUser, id: insertRes.rows[0].id };
          });
        }
      });
  };
  
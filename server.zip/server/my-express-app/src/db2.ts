// db2.ts
import { Console } from 'console';
import { Pool } from 'pg'; // Используем PostgreSQL в качестве примера

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: '12345678',
    port: 5432,
  });

export async function updateDataById(id: string, data: Record<string, any>): Promise<void> {
  const client = await pool.connect();
  try {
    const query = `
      UPDATE user_data SET
        balance = $1,
        tapValue = $2,
        tap_limit = $3,
        multitap_upgrade_cost = $4,
        energy_upgrade_cost = $5,
        full_charge_available = $6,
        hard_work_available = $7,
        energi = $9,
        time = $10
      WHERE id = $8;
    `;
    const values = [
      data.balance,
      data.tapValue,
      data.tapLimit,
      data.multitapUpgradeCost,
      data.energyUpgradeCost,
      data.fullChargeAvailable,
      data.hardWorkAvailable,
      id,
      data.currentCharge,
      new Date()
    ];
    console.log(values);

    await client.query(query, values);
  } catch (err) {
    console.error('Error updating data:', err);
    throw err;
  } finally {
    client.release();
  }
}

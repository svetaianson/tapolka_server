const { Client } = require('pg');

const client = new Client({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: '12345678',
    port: 5432,
});

client.connect();

/**
 * Функция для увеличения параметра friend на 1 для указанного username и добавления
 * друга с его балансом в формате name:balance.
 * @param {string} username - имя пользователя, для которого нужно увеличить friend.
 * @param {string} friendName - имя друга, которого нужно добавить.
 */
export async function increaseFriendCount(username:string, friendName:string) {
    console.log(1);
    try {
        // Сначала найдем баланс друга
        const friendRes = await client.query('SELECT balance FROM user_data WHERE username = $1', [friendName]);
        
        if (friendRes.rowCount === 0) {
            console.log(`Друг с именем ${friendName} не найден.`);
            return;
        }

        const friendBalance = friendRes.rows[0].balance;

        // Обновляем пользователя
        const res = await client.query(
            `UPDATE users 
             SET friend = friend + 1, 
                 friends = jsonb_set(COALESCE(friends, '{}'::jsonb), $1::text, $2::jsonb, true) 
             WHERE username = $3 
             RETURNING friend, friends`,
            [`"${friendName}"`, `{"balance": ${friendBalance}}`, username]
        );

        if (res.rowCount > 0) {
            console.log(`У пользователя ${username} теперь ${res.rows[0].friend} друзей.`);
            console.log(`Обновленные друзья:`, res.rows[0].friends);
        } else {
            console.log(`Пользователь с именем ${username} не найден.`);
        }
    } catch (err) {
        console.error('Ошибка при обновлении:', err);
    }
}

// Пример использования функции
increaseFriendCount('user1', 'user2');

// Закрытие соединения с базой данных
process.on('exit', () => {
    client.end();
});
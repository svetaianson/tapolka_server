import { Pool } from 'pg';

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: '12345678',
    port: 5432,
});

export const updateUserFriends = async (user: string, friendName: string) => {
  const client = await pool.connect();
  try {
    const checkQuery = 'SELECT * FROM user_data WHERE username = $1;';
    const checkResult = await client.query(checkQuery, [friendName]);

    if (checkResult.rows.length === 0) {
      const updateQuery = `
        UPDATE user_data
        SET friends = friends + 1,
            frends = array_append(frends, $1)
        WHERE username = $2
        RETURNING *;
      `;

      const result = await client.query(updateQuery, [friendName, user]);

      console.log('Обновленный пользователь:', result.rows[0]);
    } else {
      console.log(`Пользователь с username=${friendName} уже существует.`);
    }
  } catch (error) {
    console.error('Ошибка при обновлении пользователя:', error);
  } finally {
    client.release();
  }
};
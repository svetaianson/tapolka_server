import { Pool } from 'pg';

// Создание пула подключений к базе данных
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: '12345678',
    port: 5432,
  });

// Функция для обновления пользователя
export const updateUserFriends = async (user: string, friendName: string) => {
  const client = await pool.connect();
  try {
    // Проверяем, существует ли строка с username=friendName
    const checkQuery = `SELECT * FROM user_data WHERE username = $1;`;
    const checkResult = await client.query(checkQuery, [friendName]);

    if (checkResult.rows.length === 0) {
      // Если userName не существует, обновляем строку с username=user
      const updateQuery = `
        UPDATE user_data
        SET friends = friends + 1,
            friends = array_append(frends, $1)
        WHERE username = $2
        RETURNING *;
      `;
      
      const result = await client.query(updateQuery, [friendName, user]);

      console.log('Обновленный пользователь:', result.rows[0]);
    } else {
      console.log(`Пользователь с username=${friendName} уже существует.`);
    }
  } catch (error) {
    console.error('Ошибка при обновлении пользователя:', error);
  } finally {
    // Освобождаем соединение
    client.release();
  }
};
